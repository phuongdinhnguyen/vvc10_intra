#if ! defined( VTM_VERSION )
#define VTM_VERSION "10.0"
#endif
